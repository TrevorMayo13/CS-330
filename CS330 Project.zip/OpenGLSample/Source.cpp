#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "meshes.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader_m.h"
#include <learnopengl/camera.h>

#include <iostream>


using namespace std; // Standard namespace

namespace {

    const char* const WINDOW_TITLE = "Brick Texture"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;


    // Main GLFW window
    GLFWwindow* window = nullptr;

    // camera
    Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
    float lastX = WINDOW_WIDTH / 2.0f;
    float lastY = WINDOW_HEIGHT / 2.0f;
    bool firstMouse = true;

    // timing
    float deltaTime = 0.0f;
    float lastFrame = 0.0f;

    // lighting
    glm::vec3 lightPos(1.2f, 1.0f, 2.0f);

    // Textures
    unsigned int brickTex, aluminumTex, blueTex, altoidTopTex, floorTex, ceramicBlack, greyTex, kongTex;

    Meshes meshes;

    glm::mat4 projection;

    bool ortho = false;

    /*Shader lightingShader("multiple_lights.vs", "multiple_lights.fs");
    Shader lightCubeShader("light_cube.vs", "light_cube.fs");*/
}
bool UInitialize(int, char* [], GLFWwindow** window);
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);
void renderRoundedBox(Shader lightingShader, float x, float y, float z);
void renderPen(Shader lightingShader, float x, float y, float z);
void renderKong(Shader lightingShader, float x, float y, float z);
void renderCoffeeMug(Shader lightingShader, float x, float y, float z);
void renderPlane(Shader lightingShader, float x, float y, float z);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &window))
        return EXIT_FAILURE;

    meshes.CreateMeshes();

    // build and compile our shader zprogram
    // ------------------------------------
    /*Shader lightingShader("multiple_lights.vs", "multiple_lights.fs");
    Shader lightCubeShader("light_cube.vs", "light_cube.fs");*/
    Shader lightingShader("multiple_lights.vs", "multiple_lights.fs");
    Shader lightCubeShader("light_cube.vs", "light_cube.fs");

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    float vertices[] = {
        // positions          // normals           // texture coords
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
         0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
    };
    // positions of the point lights
    glm::vec3 pointLightPositions[] = {
        glm::vec3(0.0f,  5.0f,  0.0f)
    };
    // first, configure the cube's VAO (and VBO)
    unsigned int VBO, cubeVAO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &VBO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindVertexArray(cubeVAO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // second, configure the light's VAO (VBO stays the same; the vertices are the same for the light object which is also a 3D cube)
    unsigned int lightCubeVAO;
    glGenVertexArrays(1, &lightCubeVAO);
    glBindVertexArray(lightCubeVAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    // note that we update the lamp's position attribute's stride to reflect the updated buffer data
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // load textures (we now use a utility function to keep the code more organized)
    // -----------------------------------------------------------------------------
    brickTex = loadTexture("brick-texture-png-26.png");
    aluminumTex = loadTexture("aluminum.png");
    blueTex = loadTexture("blue_texture.png");
    altoidTopTex = loadTexture("altoid_top.png");
    floorTex = loadTexture("floor.png");
    ceramicBlack = loadTexture("black-matte.jpg");
    greyTex = loadTexture("grey.png");
    kongTex = loadTexture("red-bumps.png");
   /* unsigned int specularMap = loadTexture(FileSystem::getPath("resources/textures/container2_specular.png").c_str());*/

    // shader configuration
    // --------------------
    lightingShader.use();
    lightingShader.setInt("material.diffuse", 0);
    lightingShader.setInt("material.specular", 1);

    projection = glm::perspective(glm::radians(camera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
    // render loop
    // -----------
    while (!glfwWindowShouldClose(window))
    {
        // per-frame time logic
        // --------------------
        float currentFrame = static_cast<float>(glfwGetTime());
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        // -----
        processInput(window);

        // render
        // ------
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // be sure to activate shader when setting uniforms/drawing objects
        lightingShader.use();
        lightingShader.setVec3("viewPos", camera.Position);
        lightingShader.setFloat("material.shininess", 32.0f);

        /*
           Here we set all the uniforms for the 5/6 types of lights we have. We have to set them manually and index
           the proper PointLight struct in the array to set each uniform variable. This can be done more code-friendly
           by defining light types as classes and set their values in there, or by using a more efficient uniform approach
           by using 'Uniform buffer objects', but that is something we'll discuss in the 'Advanced GLSL' tutorial.
        */
        // directional light
        lightingShader.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
        lightingShader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
        lightingShader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
        lightingShader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
        // point light 1
        lightingShader.setVec3("pointLights[0].position", pointLightPositions[0]);
        lightingShader.setVec3("pointLights[0].ambient", 1.00f, 0.05f, 0.05f);
        lightingShader.setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
        lightingShader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("pointLights[0].constant", 1.0f);
        lightingShader.setFloat("pointLights[0].linear", 0.09f);
        lightingShader.setFloat("pointLights[0].quadratic", 0.032f);
        // spotLight
        lightingShader.setVec3("spotLight.position", camera.Position);
        lightingShader.setVec3("spotLight.direction", camera.Front);
        lightingShader.setVec3("spotLight.ambient", 0.0f, 0.0f, 1.0f);
        lightingShader.setVec3("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
        lightingShader.setVec3("spotLight.specular", 1.0f, 1.0f, 1.0f);
        lightingShader.setFloat("spotLight.constant", 1.0f);
        lightingShader.setFloat("spotLight.linear", 0.09f);
        lightingShader.setFloat("spotLight.quadratic", 0.032f);
        lightingShader.setFloat("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
        lightingShader.setFloat("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

        // view/projection transformations
        glm::mat4 view = camera.GetViewMatrix();
        lightingShader.setMat4("projection", projection);
        lightingShader.setMat4("view", view);

        // world transformation
        glm::mat4 model = glm::mat4(1.0f);
        lightingShader.setMat4("model", model);

        // bind diffuse map
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, brickTex);
        // bind specular map


        // Render Plane
        renderPlane(lightingShader, 0.0f, 0.0f, 0.0f);

        // Render Altoid
        renderRoundedBox(lightingShader, 0.0f, 0.0f, -2.0f);

        // Render Pen
        renderPen(lightingShader, 0.5f, 0.12f, 0.0f);

        // Render Kong
        renderKong(lightingShader, -2.0f, 0.0f, 0.0f);
        
        // Render Coffee Mug
        renderCoffeeMug(lightingShader, -.5f, .0f, 1.0f);

        // also draw the lamp objects
        lightCubeShader.use();
        lightCubeShader.setMat4("projection", projection);
        lightCubeShader.setMat4("view", view);


        glBindVertexArray(lightCubeVAO);
        for (unsigned int i = 0; i < 1; i++)
        {
            model = glm::mat4(1.0f);
            model = glm::translate(model, pointLightPositions[i]);
            model = glm::scale(model, glm::vec3(0.2f)); // Make it a smaller cube
            lightCubeShader.setMat4("model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }



        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &cubeVAO);
    glDeleteVertexArrays(1, &lightCubeVAO);
    glDeleteBuffers(1, &VBO);

    meshes.DestroyMeshes();

    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        camera.ProcessKeyboard(UP, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        camera.ProcessKeyboard(DOWN, deltaTime);
        
}

// Key Callback to avoid problem of repeated execution when holding down P.
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS) {
        if (ortho) {
            projection = glm::perspective(glm::radians(camera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
            ortho = false;
        }
        else {
            projection = glm::ortho(0.0f, 4.0f, 0.0f, 3.0f, 0.1f, 100.0f);
            ortho = true;
        }
    }
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xposIn, double yposIn)
{
    float xpos = static_cast<float>(xposIn);
    float ypos = static_cast<float>(yposIn);

    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(static_cast<float>(yoffset));
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}

void renderRoundedBox(Shader lightingShader, float x, float y, float z) {
    // First Corner
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, aluminumTex);

    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    glm::mat4 scale = glm::scale(glm::vec3(.3f, .3f, 0.3f));
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    glm::mat4 translation = glm::translate(glm::vec3(-0.7f + x, 1.0f + y, -0.5f + z));
    glm::mat4 model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);



    // Second Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.3f, .3f, 0.3f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(-0.7f + x, 1.0f + y, 0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // First Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.3f, .3f, 0.3f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.7f + x, 1.0f + y, 0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // First Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.3f, .3f, 0.3f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.7f + x, 1.0f + y, -0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // Center Box
    glBindVertexArray(meshes.gBoxMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(1.995f, .3f, 1.09f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.0f + x, 1.15f + y, 0.0f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // Outer Box
    glBindVertexArray(meshes.gBoxMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(1.46f, .3f, 1.595f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.0f + x, 1.15f + y, 0.0f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // First Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.33f, .1f, 0.33f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(-0.7f + x, 1.22f + y, -0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, blueTex);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // Second Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.33f, .1f, 0.33f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(-0.7f + x, 1.22f + y, 0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, blueTex);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // First Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.33f, .1f, 0.33f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.7f + x, 1.22f + y, 0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, blueTex);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // First Corner
    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.33f, .1f, 0.33f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.7f + x, 1.22f + y, -0.5f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, blueTex);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // Center Box
    glBindVertexArray(meshes.gBoxMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(2.05f, .1f, 1.15f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.0f + x, 1.27f + y, 0.0f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, blueTex);
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    // Outer Box
    glBindVertexArray(meshes.gBoxMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(1.51f, .1f, 1.65f));
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.0f + x, 1.27f + y, 0.0f + z));
    model = translation * rotation * scale;
    lightingShader.setMat4("model", model);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, blueTex);
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
}

void renderPen(Shader lightingShader, float x, float y, float z) {

    // Pen
    glActiveTexture(0);
    glBindTexture(GL_TEXTURE_2D, greyTex);

    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    glm::mat4 scale = glm::scale(glm::vec3(.12f, 3.3f, 0.12f));
    glm::mat4 rotation = glm::rotate(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotation = glm::rotate(rotation, glm::radians(-70.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(glm::vec3(-0.7f + x, 1.0f + y, -0.5f + z));
    glm::mat4 model = translation * rotation * scale;

    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    glBindVertexArray(0);
    glEnable(GL_TEXTURE_2D); // activate texture again
}

void renderKong(Shader lightingShader, float x, float y, float z) {

    // Pen
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, kongTex);

    glBindVertexArray(meshes.gSphereMesh.vao);

    // Set the mesh transfomation values
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    glm::mat4 rotation = glm::rotate(glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 translation = glm::translate(glm::vec3(-0.7f + x, 1.0f + y, -0.5f + z));
    glm::mat4 model = translation * rotation * scale;

    lightingShader.setMat4("model", model);

    glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices/2, GL_UNSIGNED_INT, (void*)0);

    glBindVertexArray(0);
}

void renderCoffeeMug(Shader lightingShader, float x, float y, float z) {

    // Coffee Mug
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, ceramicBlack);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, ceramicBlack);

    glBindVertexArray(meshes.gCylinderMesh.vao);

    // Set the mesh transfomation values
    glm::mat4 scale = glm::scale(glm::vec3(.8f, 1.5f, 0.8f));
    glm::mat4 rotation = glm::rotate(glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 translation = glm::translate(glm::vec3(0.0f + x, 1.0f + y, 0.0f + z));
    glm::mat4 model = translation * rotation * scale;

    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    //glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

    glBindVertexArray(0);


    // Handle
    glBindVertexArray(meshes.gTorusMesh.vao);

    // Set the mesh transfomation values
    scale = glm::scale(glm::vec3(.6f, .6f, 1.0f));
    rotation = glm::rotate(glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    translation = glm::translate(glm::vec3(-0.78f + x, 1.7f + y, 0.0f + z));
    model = translation * rotation * scale;

    lightingShader.setMat4("model", model);

    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices/2);

    glBindVertexArray(0);
}

void renderPlane(Shader lightingShader, float x, float y, float z) {
    glBindTexture(GL_TEXTURE_2D, floorTex);

    glBindVertexArray(meshes.gPlaneMesh.vao);

    // Set the mesh transfomation values
    glm::mat4 scale = glm::scale(glm::vec3(5.0f, 5.0f, 5.0f));
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    glm::mat4 translation = glm::translate(glm::vec3(-0.7f+x, 0.999f+y, -0.5f+z));
    glm::mat4 model = translation * rotation * scale;

    lightingShader.setMat4("model", model);

    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }





    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, framebuffer_size_callback);
    glfwSetCursorPosCallback(*window, mouse_callback);
    glfwSetScrollCallback(*window, scroll_callback);
    glfwSetKeyCallback(*window, key_callback);
    //glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    glEnable(GL_DEPTH_TEST);

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}