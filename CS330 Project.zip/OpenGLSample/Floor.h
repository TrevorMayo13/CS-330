#pragma once
#pragma once
#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "meshes.h"
class Floor {
public:
	void render(GLint modelLoc, GLuint uCustomColorLoc, Meshes meshes) {
		// Plane
		glBindVertexArray(meshes.gPlaneMesh.vao);

		// Set the mesh transfomation values
		glm::mat4 scale = glm::scale(glm::vec3(5.0f, 5.0f, 5.0f));
		glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
		glm::mat4 translation = glm::translate(glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 model = translation * rotation * scale;
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

		// Set the custom color before drawing
		glUniform4fv(uCustomColorLoc, 1, glm::value_ptr(glm::vec4(0.30, 1.00, 0.00, 1.0)));

		glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

		// Deactivate the Vertex Array Object
		glBindVertexArray(0);
	}
};