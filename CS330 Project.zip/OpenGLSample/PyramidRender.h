#pragma once
#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
// "meshes.h"

class Pyramid {
public:
	void render(GLint modelLoc, GLuint uCustomColorLoc, Meshes meshes) {
		// First Corner
		glBindVertexArray(meshes.gPyramid3Mesh.vao);

		// Set the mesh transfomation values
		glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
		glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
		glm::mat4 translation = glm::translate(glm::vec3(-0.7f, 1.5f, -0.5f));
		glm::mat4 model = translation * rotation * scale;
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

		// Set the custom color before drawing
		glUniform4fv(uCustomColorLoc, 1, glm::value_ptr(glm::vec4(1.00, 0.00, 0.74, 1.0)));

		glDrawArrays(GL_TRIANGLE_STRIP, 0, meshes.gPyramid3Mesh.nVertices);

		// Deactivate the Vertex Array Object
		glBindVertexArray(0);
	}
};